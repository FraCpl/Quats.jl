@inline function evalpoly3(t, C::Vector{SVector{3, T}}) where T
    x1 = zero(T)
    x2 = zero(T)
    x3 = zero(T)

    @inbounds for k in length(C):-1:1
        c = C[k]
        x1 = muladd(x1, t, c[1])
        x2 = muladd(x2, t, c[2])
        x3 = muladd(x3, t, c[3])
    end

    return SVector(x1, x2, x3)
end

function crossMatCore(v)
    x, y, z = v
    o = zero(x)
    return o, z, -y, -z, o, x, y, -x, o
end

function crossMatSqCore(v)
    x, y, z = v
    x2 = x*x; y2 = y*y; z2 = z*z
    return -y2 - z2, x*y, x*z, x*y, -x2 - z2, y*z, x*z, y*z, -x2 - y2
end

function crossSqCore(a, b)
    a1, a2, a3 = a
    b1, b2, b3 = b
    o1 = (-a2*a2 - a3*a3)*b1 + a1*a2*b2 + a1*a3*b3
    o2 = (-a1*a1 - a3*a3)*b2 + a1*a2*b1 + a2*a3*b3
    o3 = (-a2*a2 - a1*a1)*b3 + a1*a3*b1 + a2*a3*b2
    return o1, o2, o3
end

crossCore(a, b) = a[2]*b[3] - a[3]*b[2], a[3]*b[1] - a[1]*b[3], a[1]*b[2] - a[2]*b[1]       # out = a × (a × b)

crossSq(a, b) = SVector(crossSqCore(a, b))
crossSq(a::Vector, b::Vector) = collect(crossSqCore(a, b))

"""
    [v×] = crossMat(v)

Compute the cross product matrix of a vector ```v```.
"""
@inline crossMat(v) = SMatrix{3, 3}(crossMatCore(v))
@inline crossMat(v::Vector) = collect(SMatrix{3, 3}(crossMatCore(v)))
@inline crossMat!(R::Matrix, v) = R .= SMatrix{3, 3}(crossMatCore(v))

"""
    [v×]² = crossMatSq(x, y, z)

Compute the squared cross product matrix of a vector ```v``` given its scalar components.
"""
@inline crossMatSq(v) = SMatrix{3, 3}(crossMatSqCore(v))
@inline crossMatSq(v::Vector) = collect(SMatrix{3, 3}(crossMatSqCore(v)))
@inline crossMatSq!(R::AbstractMatrix, v) = R .= SMatrix{3, 3}(crossMatSqCore(v))

"""
    cross!(a, b, c)

Compute a = b × c.
"""
@inline cross!(a, b, c) = a .= crossCore(b, c)

"""
    addCross!(a, b, c)

Compute a = a + b × c.
"""
@inline addCross!(a, b, c) = a .+= crossCore(b, c)

"""
    crossSq!(a, b, c)

Compute a = b × (b × c).
"""
@inline crossSq!(a, b, c) = a .= crossSqCore(b, c)

"""
    addCrossSq!(a, b, c)

Compute a = a + b × (b × c).
"""
@inline addCrossSq!(a, b, c) = a .+= crossSqCore(b, c)
