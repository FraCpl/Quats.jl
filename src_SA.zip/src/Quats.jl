# Author: F. Capolupo
# European Space Agency, 2023
module Quats
using LinearAlgebra
using StaticArrays

const ex = SVector(1.0, 0.0, 0.0)
const ey = SVector(0.0, 1.0, 0.0)
const ez = SVector(0.0, 0.0, 1.0)
const I3 = SMatrix{3, 3}(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0)

export crossMat, crossMat!, crossMatSq, crossMatSq!
export cross!, crossSq!, addCross!, addCrossSq!, crossSq
include("math.jl")


include("qCore.jl")
export q_identity,
    q_multiply, q_multiply!, q_multiplyT1!, q_multiplyT2!, q_multiplyT12!
    q_mutliplyn, q_multiplyn!
    q_toDcm, q_toDcm!,
    q_fromDcm, q_fromDcm!,
    q_fromAxes, q_fromAxes!,
    q_random,
    q_transformVector, q_transformVector!, q_transformVectorT, q_transformVectorT!
    q_transpose, q_transpose!,
    q_derivative, q_derivative!,
    q_toRv, q_fromRv, q_fromRv!,
    q_rate, q_toEuler, q_derivative, q_derivative!, q_fromEuler,
    q_slerp, q_attitudeError, q_attitudeError!, q_fromZaxis
include("q.jl")

export dcm_random,
    dcm_fromAxisAngle,
    dcm_toQuaternion,
    dcm_fromQuaternion,
    dcm_toEuler,
    dcm_toRv,
    dcm_fromRv,
    dcm_fromEuler,
    dcm_fromAxes,
    dcm_fromAxes!,
    dcm_rotAxis,
    dcm_normalize,
    dcm_rotx,
    dcm_roty,
    dcm_rotz
include("dcm.jl")

export rv_toQuaternion, rv_fromQuaternion, rv_derivative, rv_fromDcm, rv_toDcm
include("rv.jl")

export transformFrame, transformFrameInv
include("transformFrame.jl")

end
